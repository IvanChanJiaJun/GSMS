﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GSMS_Project_1
{
    public partial class CustomerForm : Form
    {
        private int customerId;
        private string customerName;
        private string customerPhoneNumber;
        private string customerEmail;

        public CustomerForm(int customerId, string customerName, string customerPhoneNumber, string customerEmail)
        {
            InitializeComponent();
            this.customerId = customerId;
            this.customerName = customerName;
            this.customerPhoneNumber = customerPhoneNumber;
            this.customerEmail = customerEmail;

            // Display customer info
            lblCustomerName.Text = "Welcome, " + customerName;
            lblCustomerPhone.Text = "Phone: " + customerPhoneNumber;
            lblCustomerEmail.Text = "Email: " + customerEmail;

            LoadProducts();
        }

        // Connection string to your database
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\GSMS.mdf;Integrated Security=True";

        // Shopping cart to store products selected by the customer
        private List<CartItem> shoppingCart = new List<CartItem>();

        public CustomerForm()
        {
            InitializeComponent();
            LoadProducts();
        }

        // Load products from the database and display them in the ListView
        private void LoadProducts()
        {
            lvProducts.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT product_id, name, price FROM Products";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["product_id"].ToString());
                    item.SubItems.Add(reader["name"].ToString());
                    item.SubItems.Add(reader["price"].ToString());
                    lvProducts.Items.Add(item);
                }

                connection.Close();
            }
        }

        // Add product to the shopping cart
        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (lvProducts.SelectedItems.Count > 0)
            {
                var selectedItem = lvProducts.SelectedItems[0];
                string productName = selectedItem.SubItems[1].Text;
                decimal productPrice = Convert.ToDecimal(selectedItem.SubItems[2].Text);

                // Use int.TryParse to check if the input is a valid number
                if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Limit the quantity per food type to 10
                if (quantity > 10)
                {
                    MessageBox.Show("You cannot add more than 10 items of a single product.", "Quantity Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Check if the product is already in the cart
                var cartItem = shoppingCart.FirstOrDefault(item => item.ProductName == productName);
                if (cartItem != null)
                {
                    // If it's already in the cart, check if adding the new quantity would exceed the limit
                    if (cartItem.Quantity + quantity > 10)
                    {
                        MessageBox.Show("You cannot add more than 10 items of a single product.", "Quantity Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    // Update the quantity of the existing item
                    cartItem.Quantity += quantity;
                }
                else
                {
                    // Add the selected product to the shopping cart
                    shoppingCart.Add(new CartItem(productName, productPrice, quantity));
                }

                // Update the cart view
                UpdateCartView();
                ClearForm();
            }
            else
            {
                MessageBox.Show("Please select a product and enter a quantity.");
            }
        }

        // Update the ListView that shows the shopping cart
        private void UpdateCartView()
        {
            lvCart.Items.Clear();
            decimal totalAmount = 0;

            foreach (var cartItem in shoppingCart)
            {
                ListViewItem item = new ListViewItem(cartItem.ProductName);
                item.SubItems.Add(cartItem.Quantity.ToString());
                lvCart.Items.Add(item);

                totalAmount += cartItem.ProductPrice * cartItem.Quantity;
            }

            // Update the total amount label
            lblTotalAmountValue.Text = totalAmount.ToString("F2");
        }

        // Process the checkout and insert data into the Orders and OrderDetails tables
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            // Check if the shopping cart is empty
            if (shoppingCart == null || shoppingCart.Count == 0)
            {
                MessageBox.Show("Your cart is empty. Please add items before proceeding to checkout.", "Empty Cart", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method if the cart is empty
            }

            // Assuming we have a customer ID, which would be retrieved from the login session
            int customerId = 1; // Example customer ID

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Insert a new order into the Orders table with status
                    string insertOrderQuery = "INSERT INTO Orders (customer_id, order_date, status) OUTPUT INSERTED.order_id VALUES (@customerId, @orderDate, @status)";
                    SqlCommand orderCommand = new SqlCommand(insertOrderQuery, connection, transaction);
                    orderCommand.Parameters.AddWithValue("@customerId", customerId);
                    orderCommand.Parameters.AddWithValue("@orderDate", DateTime.Now);
                    orderCommand.Parameters.AddWithValue("@status", "Pending");  // Set default status to "Pending"
                    int orderId = (int)orderCommand.ExecuteScalar();

                    // Insert each product in the shopping cart into the OrderDetails table
                    foreach (var cartItem in shoppingCart)
                    {
                        decimal price = GetProductPriceByName(cartItem.ProductName, connection, transaction);
                        int productId = GetProductIdByName(cartItem.ProductName, connection, transaction);

                        // Insert into OrderDetails
                        string insertOrderDetailsQuery = "INSERT INTO OrderDetails (order_id, product_id, quantity, price) VALUES (@orderId, @productId, @quantity, @price)";
                        SqlCommand orderDetailsCommand = new SqlCommand(insertOrderDetailsQuery, connection, transaction);
                        orderDetailsCommand.Parameters.AddWithValue("@orderId", orderId);
                        orderDetailsCommand.Parameters.AddWithValue("@productId", productId);
                        orderDetailsCommand.Parameters.AddWithValue("@quantity", cartItem.Quantity);
                        orderDetailsCommand.Parameters.AddWithValue("@price", price);
                        orderDetailsCommand.ExecuteNonQuery();

                        // Insert into InventoryTransactions (Purchase)
                        InsertTransaction(productId, "Purchase", cartItem.Quantity, connection, transaction);

                        // Update stock level for the purchased product
                        string updateStockQuery = "UPDATE Products SET stock_level = stock_level - @quantity WHERE product_id = @productId";
                        SqlCommand stockCommand = new SqlCommand(updateStockQuery, connection, transaction);
                        stockCommand.Parameters.AddWithValue("@quantity", cartItem.Quantity);
                        stockCommand.Parameters.AddWithValue("@productId", productId);
                        stockCommand.ExecuteNonQuery();
                    }

                    // Commit the transaction
                    transaction.Commit();
                    MessageBox.Show("Order placed successfully!");

                    // Clear the cart
                    shoppingCart.Clear();
                    UpdateCartView();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("An error occurred during checkout: " + ex.Message);
                }

                connection.Close();
            }
        }

        private void InsertTransaction(int productId, string transactionType, int quantity, SqlConnection connection, SqlTransaction transaction = null)
        {
            string insertTransactionQuery = "INSERT INTO InventoryTransactions (product_id, transaction_type, quantity, transaction_date) VALUES (@productId, @transactionType, @quantity, @transactionDate)";

            SqlCommand transactionCommand = new SqlCommand(insertTransactionQuery, connection, transaction);
            transactionCommand.Parameters.AddWithValue("@productId", productId);
            transactionCommand.Parameters.AddWithValue("@transactionType", transactionType);
            transactionCommand.Parameters.AddWithValue("@quantity", quantity);
            transactionCommand.Parameters.AddWithValue("@transactionDate", DateTime.Now);

            transactionCommand.ExecuteNonQuery();
        }

        // Get product price by product name
        private decimal GetProductPriceByName(string productName, SqlConnection connection, SqlTransaction transaction)
        {
            string query = "SELECT price FROM Products WHERE name = @productName";
            SqlCommand command = new SqlCommand(query, connection, transaction);
            command.Parameters.AddWithValue("@productName", productName);
            return (decimal)command.ExecuteScalar();
        }


        // Calculate the total amount for the order
        private decimal CalculateTotalAmount()
        {
            decimal total = 0;
            foreach (var item in shoppingCart)
            {
                total += item.ProductPrice * item.Quantity;
            }
            return total;
        }

        // Get product_id by product name
        private int GetProductIdByName(string productName, SqlConnection connection, SqlTransaction transaction)
        {
            string query = "SELECT product_id FROM Products WHERE name = @productName";
            SqlCommand command = new SqlCommand(query, connection, transaction);
            command.Parameters.AddWithValue("@productName", productName);
            return (int)command.ExecuteScalar();
        }

        private int _customerId;  // Use a different name for the class-level variable

        public CustomerForm(int customerId)  // Keep the parameter named customerId
        {
            InitializeComponent();
            this._customerId = customerId;  // Store the passed customer ID in the class-level variable
            LoadProducts();
        }



        private void CustomerOrderForm_Load(object sender, EventArgs e)
        {

        }

        private void lvProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ClearForm()
        {
            txtQuantity.Clear();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Create an instance of LoginForm
            LoginForm loginForm = new LoginForm();

            // Show the LoginForm
            loginForm.Show();

            // Optionally, hide or close the current form (MainForm)
            this.Hide();  // Hides the current MainForm
                          // this.Close();  // Alternatively, closes the current form
        }

        private void lblTotalAmountValue_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (lvCart.SelectedItems.Count > 0)
            {
                string productName = lvCart.SelectedItems[0].Text;

                // Find the cart item and remove it
                var itemToRemove = shoppingCart.FirstOrDefault(i => i.ProductName == productName);
                if (itemToRemove != null)
                {
                    shoppingCart.Remove(itemToRemove);
                }

                // Update cart view and total
                UpdateCartView();
            }
            else
            {
                MessageBox.Show("Please select an item to remove.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lvCart.SelectedItems.Count > 0)
            {
                string productName = lvCart.SelectedItems[0].Text;

                // Use int.TryParse to check if the input is a valid number
                if (!int.TryParse(txtQuantity.Text, out int newQuantity) || newQuantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Ensure the new quantity does not exceed the limit of 10
                if (newQuantity > 10)
                {
                    MessageBox.Show("You cannot add more than 10 items of a single product.", "Quantity Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Find the cart item and update its quantity
                var itemToEdit = shoppingCart.FirstOrDefault(i => i.ProductName == productName);
                if (itemToEdit != null)
                {
                    itemToEdit.Quantity = newQuantity;  // Update the item's quantity
                }

                // Update cart view and total
                UpdateCartView();
                ClearForm();
            }
            else
            {
                MessageBox.Show("Please select an item to edit.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblCustomerName_Click(object sender, EventArgs e)
        {

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
          
        }
    }


    // Class to represent a cart item
    public class CartItem
    {
        public string ProductName { get; }
        public decimal ProductPrice { get; }

        // Modify the Quantity property to allow setting the value
        public int Quantity { get; set; }

        public CartItem(string productName, decimal productPrice, int quantity)
        {
            ProductName = productName;
            ProductPrice = productPrice;
            Quantity = quantity;
        }
    }

}
