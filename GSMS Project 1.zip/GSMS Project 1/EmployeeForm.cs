﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSMS_Project_1
{
    public partial class EmployeeForm : Form
    {
        private int employeeId;
        private string name;
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\GSMS.mdf;Integrated Security=True";

        public EmployeeForm()
        {
            InitializeComponent();
        }

        public EmployeeForm(int employeeId, string name)
        {
            InitializeComponent();
            this.employeeId = employeeId;
            this.name = name;
            labelEmployeeName.Text = $"Welcome, {name}";
            LoadOrders();
            LoadProducts(); // Load products when form is initialized
        }

        // Load orders from the database and display them in the ListView
        private void LoadOrders()
        {
            lvOrders.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT order_id, customer_id, order_date, status FROM Orders";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["order_id"].ToString());
                    item.SubItems.Add(reader["customer_id"].ToString());
                    item.SubItems.Add(reader["order_date"].ToString());
                    item.SubItems.Add(reader["status"].ToString());
                    lvOrders.Items.Add(item);
                }

                connection.Close();
            }
        }

        // Load products from the database and display them in the ListView
        private void LoadProducts()
        {
            lvProducts.Items.Clear();  // Clear the current items from the ListView

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT product_id, name, price, stock_level FROM Products";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    // Create a new ListViewItem and add the data from the reader
                    ListViewItem item = new ListViewItem(reader["product_id"].ToString());
                    item.SubItems.Add(reader["name"].ToString());
                    item.SubItems.Add(reader["price"].ToString());
                    item.SubItems.Add(reader["stock_level"].ToString());

                    // Add the item to the ListView
                    lvProducts.Items.Add(item);
                }

                connection.Close();
            }
        }

        // Load order details based on the selected order
        private void lvOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvOrders.SelectedItems.Count > 0)
            {
                string orderId = lvOrders.SelectedItems[0].SubItems[0].Text;
                LoadOrderDetails(orderId);
                UpdateTotalPrice(orderId); // Update the total price when an order is selected
            }
        }

        private void LoadOrderDetails(string orderId)
        {
            lvOrderDetails.Items.Clear();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT od.product_id, p.name AS product_name, od.quantity, od.price FROM OrderDetails od " +
                               "INNER JOIN Products p ON od.product_id = p.product_id WHERE od.order_id = @orderId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@orderId", orderId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["product_id"].ToString());
                    item.SubItems.Add(reader["product_name"].ToString());
                    item.SubItems.Add(reader["quantity"].ToString());
                    item.SubItems.Add(reader["price"].ToString());
                    lvOrderDetails.Items.Add(item);
                }

                connection.Close();
            }
        }

        // Add a new item to the order
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (lvOrders.SelectedItems.Count > 0 && lvProducts.SelectedItems.Count > 0)
            {
                // Get the selected order ID from the orders ListView
                int orderId = int.Parse(lvOrders.SelectedItems[0].SubItems[0].Text);

                // Get the selected product ID and price from the products ListView
                int productId = int.Parse(lvProducts.SelectedItems[0].SubItems[0].Text);

                // Use decimal.TryParse to validate the price input
                if (!decimal.TryParse(lvProducts.SelectedItems[0].SubItems[2].Text, out decimal price))
                {
                    MessageBox.Show("Invalid price value.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Use int.TryParse to validate the quantity input
                if (!int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        // Insert the new item into the OrderDetails table
                        string insertOrderDetailsQuery = "INSERT INTO OrderDetails (order_id, product_id, quantity, price) VALUES (@orderId, @productId, @quantity, @price)";
                        SqlCommand command = new SqlCommand(insertOrderDetailsQuery, connection, transaction);
                        command.Parameters.AddWithValue("@orderId", orderId);
                        command.Parameters.AddWithValue("@productId", productId);
                        command.Parameters.AddWithValue("@quantity", quantity);
                        command.Parameters.AddWithValue("@price", price);
                        command.ExecuteNonQuery();

                        // Insert a record into the InventoryTransactions table for the purchase transaction
                        string insertTransactionQuery = "INSERT INTO InventoryTransactions (product_id, transaction_type, quantity, transaction_date) " +
                                                        "VALUES (@productId, 'Purchase', @quantity, @transactionDate)";
                        SqlCommand transactionCommand = new SqlCommand(insertTransactionQuery, connection, transaction);
                        transactionCommand.Parameters.AddWithValue("@productId", productId);
                        transactionCommand.Parameters.AddWithValue("@quantity", quantity);
                        transactionCommand.Parameters.AddWithValue("@transactionDate", DateTime.Now);
                        transactionCommand.ExecuteNonQuery();

                        // Commit the transaction
                        transaction.Commit();

                        MessageBox.Show("Item added to the order successfully.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                // Clear the TextBox for quantity
                txtQuantity.Clear();

                // Optionally reload the order details to reflect the newly added item
                LoadOrderDetails(orderId.ToString());
                UpdateTotalPrice(orderId.ToString()); // Update total price
            }
            else
            {
                MessageBox.Show("Please select an order and a product to add.");
            }
        }

        // Edit the selected item in the order
        private void btnEditItem_Click(object sender, EventArgs e)
        {
            if (lvOrderDetails.SelectedItems.Count > 0)
            {
                string orderId = lvOrders.SelectedItems[0].SubItems[0].Text;
                string productId = lvOrderDetails.SelectedItems[0].SubItems[0].Text;

                // Prompt the user to enter a new quantity and use TryParse to validate the input
                string input = Prompt.ShowDialog("Enter new Quantity:", "Edit Quantity");

                if (!int.TryParse(input, out int newQuantity) || newQuantity <= 0)
                {
                    MessageBox.Show("Please enter a valid quantity.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE OrderDetails SET quantity = @quantity WHERE order_id = @orderId AND product_id = @productId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@quantity", newQuantity);
                    command.Parameters.AddWithValue("@orderId", orderId);
                    command.Parameters.AddWithValue("@productId", productId);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                LoadOrderDetails(orderId);
                UpdateTotalPrice(orderId); // Update total price
            }
            else
            {
                MessageBox.Show("Please select an item to edit.");
            }
        }

        // Delete the selected item from the order
        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (lvOrderDetails.SelectedItems.Count > 0)
            {
                string orderId = lvOrders.SelectedItems[0].SubItems[0].Text;
                string productId = lvOrderDetails.SelectedItems[0].SubItems[0].Text;
                int quantity = int.Parse(lvOrderDetails.SelectedItems[0].SubItems[2].Text);  // Get the quantity being deleted

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        // 1. Log the deletion as a "Refund" in the InventoryTransactions table
                        InsertTransaction(int.Parse(productId), "Refund", quantity, connection, transaction);

                        // 2. Update the stock level of the product by adding back the deleted quantity
                        string updateStockQuery = "UPDATE Products SET stock_level = stock_level + @quantity WHERE product_id = @productId";
                        SqlCommand stockCommand = new SqlCommand(updateStockQuery, connection, transaction);
                        stockCommand.Parameters.AddWithValue("@quantity", quantity);
                        stockCommand.Parameters.AddWithValue("@productId", productId);
                        stockCommand.ExecuteNonQuery();

                        // 3. Delete the item from OrderDetails
                        string query = "DELETE FROM OrderDetails WHERE order_id = @orderId AND product_id = @productId";
                        SqlCommand command = new SqlCommand(query, connection, transaction);
                        command.Parameters.AddWithValue("@orderId", orderId);
                        command.Parameters.AddWithValue("@productId", productId);
                        command.ExecuteNonQuery();

                        // 4. Check if the order still has items remaining in the OrderDetails table
                        string checkOrderQuery = "SELECT COUNT(*) FROM OrderDetails WHERE order_id = @orderId";
                        SqlCommand checkOrderCommand = new SqlCommand(checkOrderQuery, connection, transaction);
                        checkOrderCommand.Parameters.AddWithValue("@orderId", orderId);
                        int remainingItems = (int)checkOrderCommand.ExecuteScalar();

                        if (remainingItems == 0)
                        {
                            // If there are no more items in the order, delete the order itself from the Orders table
                            string deleteOrderQuery = "DELETE FROM Orders WHERE order_id = @orderId";
                            SqlCommand deleteOrderCommand = new SqlCommand(deleteOrderQuery, connection, transaction);
                            deleteOrderCommand.Parameters.AddWithValue("@orderId", orderId);
                            deleteOrderCommand.ExecuteNonQuery();

                            // Remove the order from the ListView
                            lvOrders.SelectedItems[0].Remove();
                            MessageBox.Show("The order has been removed as it no longer contains any items.");
                        }

                        // Commit the transaction
                        transaction.Commit();

                        // Reload the order details and update total price if the order still exists
                        if (remainingItems > 0)
                        {
                            LoadOrderDetails(orderId);
                            UpdateTotalPrice(orderId);
                        }
                        else
                        {
                            // Clear the order details view if the order is removed
                            lvOrderDetails.Items.Clear();
                            lblTotalPrice.Text = "Total Price: $0.00";
                        }
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            // Attempt to roll back the transaction
                            if (transaction.Connection != null)
                            {
                                transaction.Rollback();
                            }
                        }
                        catch (InvalidOperationException rollbackEx)
                        {
                            // Handle the case where rollback fails (e.g., because the transaction was already completed)
                            MessageBox.Show("Transaction rollback failed: " + rollbackEx.Message);
                        }

                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an item to delete.");
            }
        }

        private void InsertTransaction(int productId, string transactionType, int quantity, SqlConnection connection, SqlTransaction transaction = null)
        {
            string insertTransactionQuery = "INSERT INTO InventoryTransactions (product_id, transaction_type, quantity, transaction_date) VALUES (@productId, @transactionType, @quantity, @transactionDate)";

            SqlCommand transactionCommand = new SqlCommand(insertTransactionQuery, connection, transaction);
            transactionCommand.Parameters.AddWithValue("@productId", productId);
            transactionCommand.Parameters.AddWithValue("@transactionType", transactionType);
            transactionCommand.Parameters.AddWithValue("@quantity", quantity);
            transactionCommand.Parameters.AddWithValue("@transactionDate", DateTime.Now);

            transactionCommand.ExecuteNonQuery();
        }

        // Delete the selected order entirely
        private void btnDeleteOrder_Click(object sender, EventArgs e)
        {
            if (lvOrders.SelectedItems.Count > 0)
            {
                string orderId = lvOrders.SelectedItems[0].SubItems[0].Text;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Delete related order details first
                    string deleteOrderDetailsQuery = "DELETE FROM OrderDetails WHERE order_id = @orderId";
                    SqlCommand orderDetailsCommand = new SqlCommand(deleteOrderDetailsQuery, connection);
                    orderDetailsCommand.Parameters.AddWithValue("@orderId", orderId);

                    // Delete the order itself
                    string deleteOrderQuery = "DELETE FROM Orders WHERE order_id = @orderId";
                    SqlCommand orderCommand = new SqlCommand(deleteOrderQuery, connection);
                    orderCommand.Parameters.AddWithValue("@orderId", orderId);

                    connection.Open();
                    orderDetailsCommand.ExecuteNonQuery();
                    orderCommand.ExecuteNonQuery();
                    connection.Close();
                }

                LoadOrders();
                lvOrderDetails.Items.Clear(); // Clear the details view
                lblTotalPrice.Text = "Total Price: $0.00"; // Reset total price
            }
            else
            {
                MessageBox.Show("Please select an order to delete.");
            }
        }

        // Calculate and display the total price of the current order
        private void UpdateTotalPrice(string orderId)
        {
            decimal totalPrice = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT SUM(price * quantity) AS total_price FROM OrderDetails WHERE order_id = @orderId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@orderId", orderId);
                connection.Open();
                totalPrice = (decimal)command.ExecuteScalar();
                connection.Close();
            }

            lblTotalPrice.Text = $"Total Price: ${totalPrice:F2}";
        }

        private void lvOrderDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Handle the event when a different item in the OrderDetails list is selected
            if (lvOrderDetails.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lvOrderDetails.SelectedItems[0];
                string productId = selectedItem.SubItems[0].Text;
                string productName = selectedItem.SubItems[1].Text;
                string quantity = selectedItem.SubItems[2].Text;

                // You can now use productId, productName, and quantity for any further action
                MessageBox.Show($"Selected Product ID: {productId}\nProduct Name: {productName}\nQuantity: {quantity}");
            }
        }

        private void lvProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Handle product selection if needed
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {

        }

        private void EmployeeForm_Load_1(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Create an instance of LoginForm
            LoginForm loginForm = new LoginForm();

            // Show the LoginForm
            loginForm.Show();

            // Optionally, hide or close the current form (MainForm)
            this.Hide();  // Hides the current MainForm
                          // this.Close();  // Alternatively, closes the current form
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();  // Closes the entire application
        }

        private void cmbOrderStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdateStatus_Click(object sender, EventArgs e)
        {
            if (lvOrders.SelectedItems.Count > 0)
            {
                string orderId = lvOrders.SelectedItems[0].SubItems[0].Text; // Get the selected order's ID
                string newStatus = cmbOrderStatus.SelectedItem.ToString(); // Get the new status from the ComboBox

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Orders SET status = @status WHERE order_id = @orderId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@status", newStatus);
                    command.Parameters.AddWithValue("@orderId", orderId);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                // Update the ListView to reflect the change
                lvOrders.SelectedItems[0].SubItems[3].Text = newStatus;
                MessageBox.Show("Order status updated successfully.");
            }
            else
            {
                MessageBox.Show("Please select an order to update.");
            }
        }
    }

    // Helper class for prompting input
    public static class Prompt
    {
        public static string ShowDialog(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 500,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
            TextBox inputBox = new TextBox() { Left = 50, Top = 50, Width = 400 };
            Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 100, Top = 70, DialogResult = DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(inputBox);
            prompt.Controls.Add(confirmation);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? inputBox.Text : "";
        }
    }
}
