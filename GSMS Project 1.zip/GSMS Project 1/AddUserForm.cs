﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSMS_Project_1
{
    public partial class AddUserForm : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\GSMS.mdf;Integrated Security=True";
        private bool isEmployee;

        public AddUserForm(bool isEmployee)
        {
            InitializeComponent();
            this.isEmployee = isEmployee;
            if (isEmployee)
            {
                lblTitle.Text = "Add Employee";
                lblEmailOrPosition.Text = "Position";
                lblPhoneOrRole.Text = "Role";
                txtEmailOrPosition.Visible = true;
                txtPhoneOrRole.Visible = true;
            }
            else
            {
                lblTitle.Text = "Add Customer";
                lblEmailOrPosition.Text = "Email";
                lblPhoneOrRole.Text = "Phone Number";
                txtEmailOrPosition.Visible = true;
                txtPhoneOrRole.Visible = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string emailOrPosition = txtEmailOrPosition.Text;
            string phoneOrRole = txtPhoneOrRole.Text;
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (isEmployee)
            {
                AddEmployee(name, emailOrPosition, phoneOrRole, username, password);
            }
            else
            {
                AddCustomer(name, emailOrPosition, phoneOrRole, username, password);
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void AddEmployee(string name, string position, string role, string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Employees (name, position, role, username, password) VALUES (@name, @position, @role, @username, @password)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@position", position);
                command.Parameters.AddWithValue("@role", role);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        private void AddCustomer(string name, string email, string phoneNumber, string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Customers (name, email, phone_number, username, password) VALUES (@name, @email, @phoneNumber, @username, @password)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
