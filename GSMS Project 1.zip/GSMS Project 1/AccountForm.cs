﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSMS_Project_1
{
    public partial class AccountForm : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\GSMS.mdf;Integrated Security=True";

        public AccountForm()
        {
            InitializeComponent();
            LoadEmployees();
            LoadCustomers();
        }

        // Load employees including username and password
        private void LoadEmployees()
        {
            lvEmployees.Items.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT employee_id, name, position, role, username, password FROM Employees";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["employee_id"].ToString());
                    item.SubItems.Add(reader["name"].ToString());
                    item.SubItems.Add(reader["position"].ToString());
                    item.SubItems.Add(reader["role"].ToString());
                    item.SubItems.Add(reader["username"].ToString());
                    item.SubItems.Add(reader["password"].ToString());
                    lvEmployees.Items.Add(item);
                }

                connection.Close();
            }
        }

        // Load customers including username and password
        private void LoadCustomers()
        {
            lvCustomers.Items.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT customer_id, name, email, phone_number, username, password FROM Customers";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["customer_id"].ToString());
                    item.SubItems.Add(reader["name"].ToString());
                    item.SubItems.Add(reader["email"].ToString());
                    item.SubItems.Add(reader["phone_number"].ToString());
                    item.SubItems.Add(reader["username"].ToString());
                    item.SubItems.Add(reader["password"].ToString());
                    lvCustomers.Items.Add(item);
                }

                connection.Close();
            }
        }

        private void btnAddUser_Click_1(object sender, EventArgs e)
        {
            // Ask whether the user wants to add an Employee or a Customer
            DialogResult result = MessageBox.Show("Do you want to add an employee?", "Choose User Type", MessageBoxButtons.YesNo);

            bool isEmployee = (result == DialogResult.Yes);

            // Open the AddUserForm based on the user's choice
            using (AddUserForm addUserForm = new AddUserForm(isEmployee))
            {
                if (addUserForm.ShowDialog() == DialogResult.OK)
                {
                    // After the form is submitted, reload the users in the AccountForm
                    if (isEmployee)
                    {
                        LoadEmployees();
                    }
                    else
                    {
                        LoadCustomers();
                    }
                }
            }
        }

        // Edit user button
        private void btnEditUser_Click(object sender, EventArgs e)
        {
            // Logic for editing user accounts
            if (lvEmployees.SelectedItems.Count > 0 || lvCustomers.SelectedItems.Count > 0)
            {
                bool isEmployee = lvEmployees.SelectedItems.Count > 0;
                ListViewItem selectedItem = isEmployee ? lvEmployees.SelectedItems[0] : lvCustomers.SelectedItems[0];
                int userId = int.Parse(selectedItem.SubItems[0].Text);

                EditUserForm editUserForm = new EditUserForm(userId, isEmployee);

                // Subscribe to the UserUpdated event
                editUserForm.UserUpdated += (s, ev) =>
                {
                    if (isEmployee)
                    {
                        LoadEmployees();  // Reload employees when updated
                    }
                    else
                    {
                        LoadCustomers();  // Reload customers when updated
                    }
                };

                // Use ShowDialog to ensure changes can be handled before moving on
                editUserForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a user to edit.");
            }
        }

        // Method to clear selections in both list views
        private void ClearSelections()
        {
            lvEmployees.SelectedItems.Clear();
            lvCustomers.SelectedItems.Clear();
        }



        // Delete user button
        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            // Logic for deleting user accounts
            if (lvEmployees.SelectedItems.Count > 0 || lvCustomers.SelectedItems.Count > 0)
            {
                bool isEmployee = lvEmployees.SelectedItems.Count > 0;
                ListViewItem selectedItem = isEmployee ? lvEmployees.SelectedItems[0] : lvCustomers.SelectedItems[0];
                int userId = int.Parse(selectedItem.SubItems[0].Text);

                DialogResult result = MessageBox.Show($"Are you sure you want to delete this {(isEmployee ? "employee" : "customer")}?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        string deleteQuery = isEmployee
                            ? "DELETE FROM Employees WHERE employee_id = @userId"
                            : "DELETE FROM Customers WHERE customer_id = @userId";

                        SqlCommand command = new SqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@userId", userId);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }

                    MessageBox.Show($"{(isEmployee ? "Employee" : "Customer")} deleted successfully!");

                    // Reload the updated lists after deletion
                    if (isEmployee)
                    {
                        LoadEmployees();
                    }
                    else
                    {
                        LoadCustomers();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a user to delete.");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            adminForm.Show();
            this.Hide();
        }

        private void lvCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AccountForm_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();  // Closes the entire application
        }
    }
}
