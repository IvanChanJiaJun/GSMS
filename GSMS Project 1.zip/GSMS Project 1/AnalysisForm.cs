﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSMS_Project_1
{
    public partial class AnalysisForm : Form
    {
        private string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\GSMS.mdf;Integrated Security=True";

        public AnalysisForm()
        {
            InitializeComponent();
        }

        // This method is called when the form loads
        private void AnalysisForm_Load(object sender, EventArgs e)
        {
            // Optionally, you can load transactions automatically when the form loads
            LoadTransactions();
        }

        // Method to load transactions into the ListView
        private void LoadTransactions()
        {
            lvTransactions.Items.Clear(); // Clear any existing items

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT transaction_id, product_id, transaction_type, quantity, transaction_date FROM InventoryTransactions";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ListViewItem item = new ListViewItem(reader["transaction_id"].ToString());
                    item.SubItems.Add(reader["product_id"].ToString());
                    item.SubItems.Add(reader["transaction_type"].ToString());
                    item.SubItems.Add(reader["quantity"].ToString());
                    item.SubItems.Add(Convert.ToDateTime(reader["transaction_date"]).ToString("yyyy-MM-dd"));
                    lvTransactions.Items.Add(item);
                }

                connection.Close();
            }
        }

        // This event handler is for the Load Transactions button
        private void btnLoadTransactions_Click(object sender, EventArgs e)
        {
            LoadTransactions();
        }

        private void lvTransactions_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            // Get the path to the user's desktop
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "InventoryTransactions.csv");

            string query = "SELECT * FROM InventoryTransactions";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Create a StreamWriter to write to the file on the desktop
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the header line
                    writer.WriteLine("Transaction ID,Product ID,Transaction Type,Quantity,Transaction Date");

                    // Write each record
                    while (reader.Read())
                    {
                        string line = $"{reader["transaction_id"]},{reader["product_id"]},{reader["transaction_type"]},{reader["quantity"]},{reader["transaction_date"]}";
                        writer.WriteLine(line);
                    }
                }

                MessageBox.Show($"Transactions exported to {filePath}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminForm adminForm = new AdminForm();
            // Show the AdminForm
            adminForm.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();  // Closes the entire application
        }
    }
}
